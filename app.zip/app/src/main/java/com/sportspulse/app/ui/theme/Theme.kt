package com.sportspulse.app.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary = AccentGreenLight,
    onPrimary = OnPrimaryLight,
    surface = SurfaceLight,
    surfaceContainer = SurfaceContainerLight,
    surfaceContainerHigh = SurfaceContainerHighLight,
    onSurface = OnSurfaceLight,
    onSurfaceVariant = OnSurfaceVariantLight,
    outlineVariant = OutlineVariantLight,
    error = ErrorLight,
    background = SurfaceLight,
    onBackground = OnSurfaceLight,
)

private val DarkColorScheme = darkColorScheme(
    primary = AccentGreenDark,
    onPrimary = OnPrimaryDark,
    surface = SurfaceDark,
    surfaceContainer = SurfaceContainerDark,
    surfaceContainerHigh = SurfaceContainerHighDark,
    onSurface = OnSurfaceDark,
    onSurfaceVariant = OnSurfaceVariantDark,
    outlineVariant = OutlineVariantDark,
    error = ErrorDark,
    background = SurfaceDark,
    onBackground = OnSurfaceDark,
)

// Culorile textului pe cardurile vizitate - nu exista in ColorScheme-ul Material3, deci le
// punem intr-un CompositionLocal propriu, setat in SportsPulseTheme in functie de tema.
@Immutable
data class VisitedTextColors(val title: Color, val body: Color)

val LocalVisitedTextColors = staticCompositionLocalOf {
    VisitedTextColors(title = VisitedTitleLight, body = VisitedBodyLight)
}

@Composable
fun SportsPulseTheme(
    // Daca userul a ales explicit din Settings, respectam alegerea lui; altfel urmam sistemul.
    darkTheme: Boolean = ThemeState.darkModeOverride.value ?: isSystemInDarkTheme(),
    // Material You (culori dinamice din wallpaper) - disponibil din Android 12 (API 31),
    // exact minSdk-ul nostru. Dezactivat implicit ca sa pastram brandul verde
    // consistent; poate fi activat din Settings daca vrei sa oferi optiunea userului.
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    // Fundalul barei de status vine deja din edge-to-edge (enableEdgeToEdge() in MainActivity) +
    // Surface-urile proprii cu statusBarsPadding() - nu mai setam statusBarColor manual (API deprecat).
    // Controlam doar culoarea iconitelor sistemului (ceas, baterie etc.) sa fie lizibile pe fundal.
    val activity = LocalContext.current as? Activity
    val view = LocalView.current
    if (activity != null && !view.isInEditMode) {
        SideEffect {
            val controller = WindowCompat.getInsetsController(activity.window, view)
            controller.isAppearanceLightStatusBars = !darkTheme
        }
    }

    val visitedTextColors = if (darkTheme) {
        VisitedTextColors(title = VisitedTitleDark, body = VisitedBodyDark)
    } else {
        VisitedTextColors(title = VisitedTitleLight, body = VisitedBodyLight)
    }

    CompositionLocalProvider(LocalVisitedTextColors provides visitedTextColors) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = AppTypography,
            content = content,
        )
    }
}
